package POE;

import java.util.Scanner;
import javax.swing.JOptionPane;

public class Main {

    public static void main(String[] args) {
        //DECLARING variables
        String username, password, firstName, lastName;

        //callin classes and their methods
        Login log = new Login();
        Task task = new Task();

        String storeFirst = null, storeLast = null, storeUsername = null, storePassword = null;  //declared variaable to store the first name,last name, password and username for case 2

        //Using scanner to capture user input
        Scanner scan = new Scanner(System.in);

        while (true) { //using while loop to loop the question, ansewrs and conditon (Until the conditon true)
            //Displaying options for the user to choose
            System.out.println("Welcome! Please choose the following:\n"
                    + "1-Create an accoint\n"
                    + "2-Login into your account\n"
                    + "3-EXIT");
            int response = scan.nextInt();

            //Using switch case so the user can be able to choose 
            switch (response) {
                case 1: //When user chooses 1 (Create an account)
                    System.out.print("Please enter your first name:");
                    scan.nextLine();// Consume the newline character
                    firstName = scan.nextLine();

                    System.out.print("Please enter your last name:");
                    lastName = scan.nextLine();

                    System.out.print("Please enter username.Username must contains: \n"
                            + "-an underscore\n"
                            + "-and is no more than 5 characters:\n");
                    username = scan.nextLine();

                    //Conditions to check the username is correct
                    if (log.checkUserName(username)) {

                        while (firstName == null || lastName == null || storeUsername == null || storePassword == null) { //when username is correct procced to password
                            System.out.println("Please enter password. Password meets the following: \n"
                                    + "-At least 8 characters long\n"
                                    + "-Contain a capital letter\n"
                                    + "-Contain a number\n"
                                    + "- Contain a special character:");

                            password = scan.nextLine();

                            //Will display when username or password is incorrect or correct resterimg user
                            String displayRegistration = log.registerUser(username, password);
                            System.out.println(displayRegistration);

                            //Condition to check the password is correct and store user's imput
                            if (log.checkPasswordComplexity(password)) {
                                //Store the user's password and username for the login option. Also stores the user's first and last name
                                storeFirst = firstName;
                                storeLast = lastName;
                                storeUsername = username;
                                storePassword = password;

                            }
                        }
                    }

                    break;

                case 2: //When user chooses 2 (Login into an account)

                    //if statement if the user wants to login without creating/registering an account
                    if (storeUsername == null || storePassword == null || storeFirst == null || storeLast == null) {
                        System.out.println("No account has been created yet. Please create an account first to login");
                        System.out.println();
                    } //Asking the user for their previous input (username and passwrd)
                    else {
                        System.out.print("Please enter your Username:");

                        scan.nextLine();
                        String inputUser = scan.nextLine();

                        System.out.print("Please enter your Password:");
                        String inputPass = scan.nextLine();

                        //Condition statement to check if the username and password match and allows user to login
                        boolean loginUserStatus = log.loginUser(inputUser, inputPass, storePassword, storeUsername, storeFirst, storeLast);
                        String displayReturnLoginStatus = log.returnLoginStatus(inputUser, inputPass, storePassword, storeUsername, storeFirst, storeLast, loginUserStatus);

                        //Display the login status
                        System.out.print(displayReturnLoginStatus);

                        /*TASK 2
                        After everything is cleared the user can then add task
                         */
                        //A if condition will check if the username and password works and allow the user to add task
                        if (loginUserStatus) {
                            System.out.println("Welcome to EasyKanban");

                            //will repeat until it is true
                            while (true) {
                                System.out.println("Please choose an option:\n"
                                        + "1- Add tasks \n"
                                        + "2- Show report\n"
                                        + "3- Quit \n");
                                int response2 = scan.nextInt();

                                //The user will able to choose the option after being prompt
                                switch (response2) {
                                    case 1:
                                        System.out.println("How many tasks do you want to add?");
                                        int numberOfTasks = scan.nextInt();
                                        scan.nextLine();

                                        //declaring for the total amount of hours
                                        int totalOfHours = 0;

                                        //A for loop to print out the number of tasks the user would like to add
                                        for (int i = 0; i < numberOfTasks; i++) {
                                            System.out.print("Task Name: ");
                                            String taskName = scan.nextLine();

                                            //adding task number and will be incremented
                                            int taskNumber = (i + 1);
                                            System.out.println("Task Number: " + taskNumber);

                                            System.out.println("Please enter a task description of less than 50 characters:");
                                            String taskDescription = "";

                                            //will ask the user to enter the correct amounnt till task is successfully capture
                                            boolean validDescription = false;
                                            while (!validDescription) {
                                                taskDescription = scan.nextLine();

                                                //check the task description conditions
                                                task.checkTaskDescription(taskDescription);
                                            }

                                            //adding the Developer name and last name
                                            System.out.print("Enter Developer's first name: ");
                                            String developerFirstName = scan.nextLine();

                                            System.out.print("Enter Developer's last name: ");
                                            String developerLastName = scan.nextLine();

                                            //adding the duration
                                            System.out.print("Task Duration (in hours)");
                                            int taskDuration = scan.nextInt();

                                           //total hours
                                            totalOfHours = totalOfHours + taskDuration; //Will accumulate the task duration
                                            task.addTaskDuration(taskDuration); //add the duration to the total in the Task class
                                            

                                            //creating the task ID and calling it in the method
                                            String taskID = task.createTaskID(taskName, taskNumber, developerLastName);

                                            //menu for track Status
                                            System.out.println("Select Status \n"
                                                    + "1-To Do \n"
                                                    + "2-Done"
                                                    + "3-Doing");

                                            int statusOption = scan.nextInt();

                                            //Store the track Status output
                                            String trackStatus;
                                            switch (statusOption) {
                                                case 1:
                                                    trackStatus = "To Do";
                                                    break;

                                                case 2:
                                                    trackStatus = "Done";
                                                    break;

                                                case 3:
                                                    trackStatus = "Doing";
                                                    break;

                                                default:
                                                    trackStatus = "Not Known";
                                                    break;
                                            }

                                            //Displaying the task details 
                                            String taskDiplay = task.printTaskDetails(trackStatus, developerFirstName, developerLastName, taskNumber, taskName, taskDescription, taskID, totalOfHours);
                                        }
                                        break;

                                    case 2:
                                        System.out.println("Coming soon");
                                        System.exit(0);
                                        break;

                                    //exit the task option
                                    case 3:
                                        System.out.println("Thank you for visiting! Hope to see you soon!");
                                        System.exit(0);
                                        break;

                                    //when the user enters the wrong task option
                                    default:
                                        System.out.println("Invaild option please slecect correct option");

                                }
                            }
                        }
                    }
                    break;

                //when user wants to exit
                case 3:
                    System.out.println("Thank you for visiting! Hope to see you soon!");
                    System.exit(0);

                //when the user enters the wrong option
                default:
                    System.out.println("Invaild option please slecect correct option");
            }
        }

    }
}
