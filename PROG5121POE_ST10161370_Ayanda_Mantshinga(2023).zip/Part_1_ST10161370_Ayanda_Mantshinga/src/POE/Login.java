package POE;

//the login class
public class Login {

    private String username, password, inputUser, inputPass;
    private String storeUsername, storePassword, storeFirst, storeLast;
    String underscore = "_";

    //A method to check if the username conditions are correct
    public boolean checkUserName(String username) {
        if (username.length() <= 5 && username.contains(underscore)) {
            System.out.println("Username successfully captured");
            return true; //when the condition is met it will return true
        } else {
            System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in lengt");
            return false; //when the condition is met it will return false
        }
    }

//A method to check if the password are correct
    public boolean checkPasswordComplexity(String password) {
        //boolean that will be match the password (seriers of characters)
        boolean alpfa = password.matches(".*[A-Z].*"),
                sp = password.matches(".*[!@#$%^&+-].*"),
                num = password.matches(".*[0-9].*");

        //a condition that will check password is correct
        if (password.length() >= 8 && alpfa && sp && num) {
            System.out.println("Password successfully captured");
            System.out.println("Your account has been succesfully created");
            System.out.println();  //empty line for formating will allow it to jump back the menu
            return true;
        } else {
            System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character");
            return false;
        }
    }

    //This method returns the necessary registration messaging 
    public String registerUser(String username, String password) {

        if (!checkUserName(username) || !checkPasswordComplexity(password)) { //PASS IN THE REGISTRATION IS CORRECT
            this.username = username;
            this.password = password;
            return "The username or password incorrect";
        } else {
            return "You registered succesfully";
        }
    }

    public boolean loginUser(String inputUser, String inputPass, String storePassword, String storeUsername, String storeFirst, String storeLast) {

        if (inputUser.equals(storeUsername) && inputPass.equals(storePassword)) {
            return true;
        } else {
            return false;
        }
    }

    //This method returns the necessary messaging for succes login or faild
    public String returnLoginStatus(String inputUser, String inputPass, String storePassword, String storeUsername, String storeFirst, String storeLast, boolean loginUserStatus) {
        if (loginUserStatus) {
            return "Sucessful login \n" + "Welcome " + storeFirst + ", " + storeLast + " it is great to see you again.";
        } else {

            return "Failed login \n" + "Username or password incorrect, please try again";
        }
    }

}
