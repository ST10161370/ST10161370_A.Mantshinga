package POE;

import javax.swing.JOptionPane;

public class Task {

    private String taskDescription, taskName, developerFirstName, developerLastName, trackStatus;
    private int taskNumber, totalHours, taskDuration;

    boolean checkTaskDescription(String taskDescription) {
        boolean validDescription = false;
        if (taskDescription.length() > 50) {
            System.out.println("Please enter a task description of less than 50 characters");
            return true;
        } else {
            validDescription = true;
            System.out.println("Task successfully captured");
            return false;
        }
    }

    //Task ID generator method
    String createTaskID(String taskName, int taskNumber, String developerLastName) {
        String firstTwoLetters = taskName.substring(0, 2).toUpperCase();
        String lastThreeLetters = developerLastName.substring(developerLastName.length() - 3).toUpperCase();
        return firstTwoLetters + ":" + taskNumber + ":" + lastThreeLetters;
    }

    String printTaskDetails(String trackStatus, String developerFirstName, String developerLastName, int taskNumber, String taskName, String taskDescription, String taskID, int totalOfHours) {
        String taskDisplay = "Track Status: " + trackStatus + "\n"
                + "Developer Details: " + developerFirstName + "" + developerLastName + "\n"
                + "Task numner: " + taskNumber + "\n"
                + "Task name: " + taskName
                + "Task Description: " + taskDescription + "\n"
                + "Task ID: " + taskID + "\n"
                + "Task Duration: " + totalOfHours + " hours";
        JOptionPane.showMessageDialog(null, taskDisplay, "Task Details", JOptionPane.INFORMATION_MESSAGE);
        return taskDisplay;
    }

    int returnTotalHours() {
      return totalHours;
    }
    
    void addTaskDuration (int taskDuration){
        totalHours = totalHours + taskDuration;
    }
}
